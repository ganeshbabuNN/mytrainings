a = 12
b = 12
c = 12.0

# fsfsedfsdfs 
print(id(a))
id(b)
id(c)

'''
This is Ultimate data science batch v2.0.
In this class we are learning python variable
This is Ultimate data science batch v2.0.
In this class we are learning python variable
This is Ultimate data science batch v2.0.
In this class we are learning python variable
print(a)
'''
print(a)